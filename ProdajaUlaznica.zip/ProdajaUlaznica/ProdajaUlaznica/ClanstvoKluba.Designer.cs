﻿namespace ProdajaUlaznica
{
    partial class ClanstvoKluba
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBxImeClan = new System.Windows.Forms.TextBox();
            this.txtBxPrezimeClan = new System.Windows.Forms.TextBox();
            this.txtBxOIBClan = new System.Windows.Forms.TextBox();
            this.comBxSpol = new System.Windows.Forms.ComboBox();
            this.datumRodenjaClan = new System.Windows.Forms.DateTimePicker();
            this.btnUclani = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(310, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Postani član kluba";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(340, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ime";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(339, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "OIB";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(336, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Spol";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(327, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Datum rođenja";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(329, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Prezime";
            // 
            // txtBxImeClan
            // 
            this.txtBxImeClan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBxImeClan.Location = new System.Drawing.Point(313, 78);
            this.txtBxImeClan.Name = "txtBxImeClan";
            this.txtBxImeClan.Size = new System.Drawing.Size(100, 20);
            this.txtBxImeClan.TabIndex = 6;
            // 
            // txtBxPrezimeClan
            // 
            this.txtBxPrezimeClan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBxPrezimeClan.Location = new System.Drawing.Point(313, 144);
            this.txtBxPrezimeClan.Name = "txtBxPrezimeClan";
            this.txtBxPrezimeClan.Size = new System.Drawing.Size(100, 20);
            this.txtBxPrezimeClan.TabIndex = 7;
            // 
            // txtBxOIBClan
            // 
            this.txtBxOIBClan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBxOIBClan.Location = new System.Drawing.Point(313, 213);
            this.txtBxOIBClan.Name = "txtBxOIBClan";
            this.txtBxOIBClan.Size = new System.Drawing.Size(100, 20);
            this.txtBxOIBClan.TabIndex = 8;
            // 
            // comBxSpol
            // 
            this.comBxSpol.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comBxSpol.FormattingEnabled = true;
            this.comBxSpol.Items.AddRange(new object[] {
            "M",
            "Ž"});
            this.comBxSpol.Location = new System.Drawing.Point(292, 364);
            this.comBxSpol.Name = "comBxSpol";
            this.comBxSpol.Size = new System.Drawing.Size(121, 21);
            this.comBxSpol.TabIndex = 9;
            // 
            // datumRodenjaClan
            // 
            this.datumRodenjaClan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datumRodenjaClan.Location = new System.Drawing.Point(281, 285);
            this.datumRodenjaClan.Name = "datumRodenjaClan";
            this.datumRodenjaClan.Size = new System.Drawing.Size(200, 20);
            this.datumRodenjaClan.TabIndex = 10;
            // 
            // btnUclani
            // 
            this.btnUclani.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUclani.Location = new System.Drawing.Point(647, 364);
            this.btnUclani.Name = "btnUclani";
            this.btnUclani.Size = new System.Drawing.Size(116, 59);
            this.btnUclani.TabIndex = 11;
            this.btnUclani.Text = "Učlani se";
            this.btnUclani.UseVisualStyleBackColor = true;
            // 
            // ClanstvoKluba
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnUclani);
            this.Controls.Add(this.datumRodenjaClan);
            this.Controls.Add(this.comBxSpol);
            this.Controls.Add(this.txtBxOIBClan);
            this.Controls.Add(this.txtBxPrezimeClan);
            this.Controls.Add(this.txtBxImeClan);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ClanstvoKluba";
            this.Text = "ČlanstvoKluba";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBxImeClan;
        private System.Windows.Forms.TextBox txtBxPrezimeClan;
        private System.Windows.Forms.TextBox txtBxOIBClan;
        private System.Windows.Forms.ComboBox comBxSpol;
        private System.Windows.Forms.DateTimePicker datumRodenjaClan;
        private System.Windows.Forms.Button btnUclani;
    }
}